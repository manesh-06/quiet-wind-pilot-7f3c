# WindWise implementation plan

## Product
WindWise is a focused UK utility decision-support portal for the January 2026 day-ahead wind procurement pilot. It shows the forecast vintage that was actually available at the decision cutoff, compares it with national wind actuals, and quantifies forecast error.

## Design direction
Three candidate styles: quiet utility control room (0.07); editorial energy intelligence (0.06); dark trading terminal (0.04). Chosen style: **quiet utility control room**.

- **Design Movement:** Swiss information design adapted for an energy operations desk.
- **Core Principles:** evidence before decoration; calm visual hierarchy; decision-critical numbers first; explicit provenance.
- **Color Philosophy:** warm paper and ink reduce fatigue, while a single electric-lime accent signals the live decision state.
- **Layout Paradigm:** a left rail for scope and method, with a wide analysis canvas and an anchored decision brief rather than a generic centered dashboard grid.
- **Signature Elements:** lime “decision-ready” marker, hairline chart guides, and compact source/cutoff badges.
- **Interaction Philosophy:** changing the day updates every view without hiding the method; tooltips and table rows expose exact timestamps.
- **Animation:** restrained 150ms transitions for selected day and metric cards; no decorative motion.
- **Typography System:** Inter for interface text with Space Grotesk for numeric display and headings.
- **Brand Essence:** “Forecast clarity before the market window closes” for UK power buyers; calm, precise, accountable.
- **Brand Voice:** direct and operational. Example: “This is the forecast the buyer could actually see.” “Error is shown in MW, not just a score.”
- **Wordmark & Logo:** a compact wind-line mark beside the WindWise wordmark.
- **Signature Brand Color:** electric lime #C8F169.

## Implementation
- `frontend/`: Vite + React + TypeScript single-page portal. It uses a small fetch client and SVG/CSS charts to keep the MVP dependency-light.
- `backend/`: FastAPI service. `GET /api/overview` returns January 2026 sample analytics; `GET /health` supports deployment checks. The source adapter documents the Elexon endpoints and exposes a deterministic demo fallback when the public API is unavailable.
- `Dockerfile`: multi-stage container builds the React app and serves it from FastAPI in production.
- `docker-compose.yml`: local one-command startup.
- `README.md`: setup, data methodology, API contract, deployment guidance, limitations, and AI-assistance disclosure.

## Data methodology
Actuals use FUELHH records filtered to `fuelType=WIND`, `startTime`, and `generation` in MW. Forecasts use WINDFOR records with `startTime`, `publishTime`, and `generation`. For a delivery day, forecasts are eligible only when `publishTime <= previous day 23:00:00 UTC`; the latest eligible publish vintage is selected per day. Metrics are calculated on aligned 30-minute records: MAE, RMSE, mean signed bias, and MAPE where actual output is non-zero.
