from fastapi import Query

from backend.main import app
from backend.main import days as _days
from backend.main import health as _health
from backend.main import live_check as _live_check
from backend.main import overview as _overview


@app.get('/health')
def health_alias():
    return _health()


@app.get('/overview')
def overview_alias(delivery_date: str = Query('2026-01-14', alias='deliveryDate')):
    return _overview(delivery_date=delivery_date)


@app.get('/days')
def days_alias():
    return _days()


@app.get('/live-check')
def live_check_alias():
    return _live_check()


__all__ = ['app']
