from fastapi import FastAPI

from backend.main import health

app = FastAPI(title='WindWise health function')


@app.get('/')
@app.get('/health')
@app.get('/api/health')
def handler():
    return health()
