from fastapi import FastAPI, Query

from backend.main import overview

app = FastAPI(title='WindWise overview function')


@app.get('/')
@app.get('/overview')
@app.get('/api/overview')
def handler(delivery_date: str = Query('2026-01-14', alias='deliveryDate')):
    return overview(delivery_date=delivery_date)
