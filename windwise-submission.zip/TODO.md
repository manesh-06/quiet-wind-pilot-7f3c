# WindWise TODO

- [x] January 2026 scope controls restrict the pilot views and calculations to the challenge period.
- [x] Elexon source provenance is documented for FUELHH actuals and WINDFOR forecasts.
- [x] Day-ahead cutoff logic is documented and represented in the API response.
- [x] Customer dashboard shows selected forecast, actual output, error, and decision indicators.
- [x] Quantitative metrics include MAE, RMSE, bias, and MAPE where valid.
- [x] Daily and settlement-period comparison views include timestamps, units, and missing-data messaging.
- [x] Technical walkthrough covers architecture, endpoints, fields, cutoff, transformations, metrics, contracts, and limitations.
- [x] Dockerized React and Python application has reproducible local startup.
- [x] README includes setup, operating instructions, AI-assistance disclosure, and Vercel/Heroku guidance.
- [x] Replace demo fallback with a captured January 2026 Elexon snapshot and SQLite-backed API response.
- [x] Add a scheduled Elexon refresh workflow and manual refresh command.
- [x] Build and run the Docker image successfully.
- [ ] Add public GitHub repository URL and deployed URL before submission.
- [ ] Record and upload the two-part unlisted demo video.
