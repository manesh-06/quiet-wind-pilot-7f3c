export default { logoUrl: "https://dummyimage.com/256x256/c8f169/202720.png&text=W" };
