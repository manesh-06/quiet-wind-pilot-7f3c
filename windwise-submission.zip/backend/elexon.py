"""Small Elexon BMRS adapter for the January 2026 pilot.

The public gateway can rate-limit or block automated sandbox traffic, so callers should
persist successful raw responses and fall back only with an explicit mode label.
"""
from datetime import date
import requests

BASE = 'https://data.elexon.co.uk/bmrs/api/v1'


def _records(payload):
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ('data', 'items', 'results'):
            if isinstance(payload.get(key), list):
                return payload[key]
    return []


def fetch_actuals(start: date, end: date):
    response = requests.get(
        f'{BASE}/datasets/FUELHH/stream',
        params={'settlementDateFrom': start.isoformat(), 'settlementDateTo': end.isoformat(), 'fuelType': 'WIND'},
        timeout=30,
    )
    response.raise_for_status()
    return [r for r in _records(response.json()) if r.get('fuelType') in (None, 'WIND')]


def fetch_forecasts(publish_from: str, publish_to: str):
    response = requests.get(
        f'{BASE}/datasets/WINDFOR/stream',
        params={'publishDateTimeFrom': publish_from, 'publishDateTimeTo': publish_to},
        timeout=30,
    )
    response.raise_for_status()
    return _records(response.json())
