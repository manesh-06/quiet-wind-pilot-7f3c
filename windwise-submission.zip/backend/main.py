from __future__ import annotations

from datetime import date, datetime, timezone

from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware

from .elexon import fetch_actuals, fetch_forecasts
from .storage import delivery_days, latest_snapshot_status, selected_delivery_day

app = FastAPI(title='WindWise API', version='0.2.0')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])


@app.get('/health')
def health():
    return {'status': 'ok', 'service': 'windwise-api', 'storage': latest_snapshot_status()}


@app.get('/api/days')
def days():
    return {'days': delivery_days()}


@app.get('/api/overview')
def overview(delivery_date: str = Query('2026-01-14', alias='deliveryDate')):
    try:
        parsed = date.fromisoformat(delivery_date)
    except ValueError:
        parsed = date(2026, 1, 14)
    if not (date(2026, 1, 1) <= parsed < date(2026, 2, 1)):
        parsed = date(2026, 1, 14)
    selected = selected_delivery_day(parsed.isoformat())
    return {
        'scope': {'from': '2026-01-01', 'to': '2026-01-31', 'timezone': 'UTC', 'resolution': '30 minutes'},
        'decision_rule': 'latest WINDFOR publishTime at or before 23:00 UTC on the day before delivery',
        'sources': [
            {'dataset': 'FUELHH', 'role': 'actual', 'url': 'https://bmrs.elexon.co.uk/api-documentation/endpoint/datasets/FUELHH/stream', 'fields': ['startTime', 'generation', 'fuelType']},
            {'dataset': 'WINDFOR', 'role': 'forecast', 'url': 'https://bmrs.elexon.co.uk/api-documentation/endpoint/datasets/WINDFOR/stream', 'fields': ['startTime', 'publishTime', 'generation']},
        ],
        'generated_at': datetime.now(timezone.utc).isoformat(),
        'mode': 'captured-elexon-snapshot' if selected['aligned_count'] else 'unavailable',
        'snapshot_status': latest_snapshot_status(),
        'delivery': selected,
    }


@app.get('/api/live-check')
def live_check():
    """Fetch a small January slice to prove the live adapter and expose gateway errors."""
    try:
        actuals = fetch_actuals(date(2026, 1, 1), date(2026, 1, 2))
        forecasts = fetch_forecasts('2025-12-31T00:00:00Z', '2026-01-02T00:00:00Z')
        return {'mode': 'live', 'actual_rows': len(actuals), 'forecast_rows': len(forecasts)}
    except Exception as exc:
        return {'mode': 'unavailable', 'error': type(exc).__name__, 'detail': str(exc)}
