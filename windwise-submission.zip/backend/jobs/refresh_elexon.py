from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import requests

from backend.storage import DATA_DIR, replace_snapshot

BASE = 'https://data.elexon.co.uk/bmrs/api/v1'
ACTUAL_FROM = '2026-01-01'
ACTUAL_TO = '2026-02-01'
FORECAST_FROM = '2025-12-31T00:00:00Z'
FORECAST_TO = '2026-02-01T00:00:00Z'


def fetch(path: str, params: dict[str, str]) -> list[dict]:
    response = requests.get(f'{BASE}/{path}', params=params, timeout=180, headers={'Accept': 'application/json', 'User-Agent': 'WindWise-pilot/0.1'})
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, list):
        raise RuntimeError(f'Unexpected Elexon response for {path}: {type(payload).__name__}')
    return payload


def save_raw(filename: str, payload: list[dict]) -> None:
    raw_dir = DATA_DIR / 'raw'
    raw_dir.mkdir(parents=True, exist_ok=True)
    (raw_dir / filename).write_text(json.dumps(payload, indent=2), encoding='utf-8')


def main() -> None:
    actuals = fetch('datasets/FUELHH/stream', {'settlementDateFrom': ACTUAL_FROM, 'settlementDateTo': ACTUAL_TO, 'fuelType': 'WIND'})
    forecasts = fetch('datasets/WINDFOR/stream', {'publishDateTimeFrom': FORECAST_FROM, 'publishDateTimeTo': FORECAST_TO})
    # The API's date filters are inclusive in practice, so retain only January delivery targets.
    actuals = [row for row in actuals if ACTUAL_FROM <= row.get('startTime', '')[:10] < ACTUAL_TO]
    forecasts = [row for row in forecasts if ACTUAL_FROM <= row.get('startTime', '')[:10] < ACTUAL_TO]
    save_raw('FUELHH_2026-01.json', actuals)
    save_raw('WINDFOR_2026-01.json', forecasts)
    actual_snapshot = replace_snapshot('FUELHH', ACTUAL_FROM, ACTUAL_TO, actuals)
    forecast_snapshot = replace_snapshot('WINDFOR', FORECAST_FROM, FORECAST_TO, forecasts)
    print(json.dumps({'actual_rows': len(actuals), 'forecast_rows': len(forecasts), 'actual_snapshot_id': actual_snapshot, 'forecast_snapshot_id': forecast_snapshot, 'database': 'data/windwise.sqlite3'}))


if __name__ == '__main__':
    main()
