from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / 'data'
DB_PATH = DATA_DIR / 'windwise.sqlite3'

SCHEMA = '''
CREATE TABLE IF NOT EXISTS raw_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  dataset TEXT NOT NULL,
  fetched_at TEXT NOT NULL,
  request_from TEXT NOT NULL,
  request_to TEXT NOT NULL,
  row_count INTEGER NOT NULL,
  payload_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS actuals (
  start_time TEXT PRIMARY KEY,
  publish_time TEXT,
  settlement_date TEXT,
  settlement_period INTEGER,
  fuel_type TEXT NOT NULL,
  generation_mw REAL NOT NULL,
  snapshot_id INTEGER NOT NULL REFERENCES raw_snapshots(id)
);
CREATE TABLE IF NOT EXISTS forecasts (
  start_time TEXT NOT NULL,
  publish_time TEXT NOT NULL,
  generation_mw REAL NOT NULL,
  snapshot_id INTEGER NOT NULL REFERENCES raw_snapshots(id),
  PRIMARY KEY (start_time, publish_time)
);
CREATE INDEX IF NOT EXISTS idx_forecasts_delivery ON forecasts(start_time);
CREATE INDEX IF NOT EXISTS idx_forecasts_publish ON forecasts(publish_time);
'''


def connect() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.executescript(SCHEMA)
    return db


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def replace_snapshot(dataset: str, request_from: str, request_to: str, payload: list[dict[str, Any]]) -> int:
    db = connect()
    now = utc_now()
    with db:
        cur = db.execute(
            'INSERT INTO raw_snapshots(dataset,fetched_at,request_from,request_to,row_count,payload_json) VALUES (?,?,?,?,?,?)',
            (dataset, now, request_from, request_to, len(payload), json.dumps(payload, separators=(',', ':'))),
        )
        snapshot_id = cur.lastrowid
        if dataset == 'FUELHH':
            db.execute('DELETE FROM actuals')
            db.executemany(
                '''INSERT INTO actuals(start_time,publish_time,settlement_date,settlement_period,fuel_type,generation_mw,snapshot_id)
                   VALUES (:startTime,:publishTime,:settlementDate,:settlementPeriod,:fuelType,:generation,:snapshot_id)''',
                [{**row, 'snapshot_id': snapshot_id} for row in payload if row.get('fuelType') == 'WIND'],
            )
        elif dataset == 'WINDFOR':
            db.execute('DELETE FROM forecasts')
            db.executemany(
                '''INSERT INTO forecasts(start_time,publish_time,generation_mw,snapshot_id)
                   VALUES (:startTime,:publishTime,:generation,:snapshot_id)''',
                [{**row, 'snapshot_id': snapshot_id} for row in payload],
            )
    db.close()
    return int(snapshot_id or 0)


def latest_snapshot_status() -> dict[str, Any]:
    db = connect()
    rows = db.execute('SELECT dataset,fetched_at,row_count FROM raw_snapshots ORDER BY id DESC').fetchall()
    db.close()
    result: dict[str, Any] = {}
    for row in rows:
        result.setdefault(row['dataset'], {'fetched_at': row['fetched_at'], 'row_count': row['row_count']})
    return result


def delivery_days() -> list[str]:
    db = connect()
    rows = db.execute("SELECT DISTINCT substr(start_time,1,10) day FROM actuals WHERE start_time >= '2026-01-01' AND start_time < '2026-02-01' ORDER BY day").fetchall()
    db.close()
    return [row['day'] for row in rows]


def selected_delivery_day(delivery_date: str) -> dict[str, Any]:
    db = connect()
    actual_rows = db.execute(
        "SELECT start_time,publish_time,generation_mw FROM actuals WHERE start_time >= ? AND start_time < datetime(?, '+1 day') ORDER BY start_time",
        (delivery_date, delivery_date),
    ).fetchall()
    cutoff = f'{delivery_date}T00:00:00Z'
    from datetime import date, timedelta
    prior = date.fromisoformat(delivery_date) - timedelta(days=1)
    cutoff = f'{prior.isoformat()}T23:00:00Z'
    vintage = db.execute('SELECT MAX(publish_time) publish_time FROM forecasts WHERE publish_time <= ? AND start_time >= ? AND start_time < ?', (cutoff, delivery_date, f'{date.fromisoformat(delivery_date) + timedelta(days=1)}')).fetchone()['publish_time']
    forecast_rows = db.execute(
        'SELECT start_time,publish_time,generation_mw FROM forecasts WHERE publish_time = ? AND start_time >= ? AND start_time < ? ORDER BY start_time',
        (vintage, delivery_date, f'{date.fromisoformat(delivery_date) + timedelta(days=1)}'),
    ).fetchall() if vintage else []
    db.close()
    actual_by_time = {row['start_time']: row for row in actual_rows}
    points = []
    for forecast in forecast_rows:
        actual = actual_by_time.get(forecast['start_time'])
        if actual:
            points.append({'time': forecast['start_time'][11:16], 'startTime': forecast['start_time'], 'forecast': forecast['generation_mw'], 'actual': actual['generation_mw'], 'error': actual['generation_mw'] - forecast['generation_mw']})
    return {'delivery_date': delivery_date, 'cutoff': cutoff, 'vintage': vintage, 'actual_count': len(actual_rows), 'forecast_count': len(forecast_rows), 'aligned_count': len(points), 'points': points}
