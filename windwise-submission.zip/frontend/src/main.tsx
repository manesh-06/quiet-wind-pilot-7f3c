import { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

type Point = { time: string; forecast: number; actual: number; error: number };
type Day = { date: string; label: string; status: string; vintage: string; points: number[] };

const days: Day[] = [
  { date: '2026-01-14', label: 'Wed 14 Jan', status: 'decision-ready', vintage: '2026-01-13 23:00 UTC', points: [68,72,79,88,101,118,132,145,151,147,137,126,117,110,108,113,124,139,150,145,126,104,87,75] },
  { date: '2026-01-15', label: 'Thu 15 Jan', status: 'decision-ready', vintage: '2026-01-14 23:00 UTC', points: [72,75,84,93,110,129,144,153,158,155,149,140,132,125,119,120,128,140,146,138,121,99,82,70] },
  { date: '2026-01-16', label: 'Fri 16 Jan', status: 'decision-ready', vintage: '2026-01-15 23:00 UTC', points: [54,60,70,83,98,115,128,137,142,140,133,124,115,108,103,105,113,124,131,129,118,98,76,61] }
];

function makePoints(raw: number[], dayIndex: number): Point[] {
  return raw.map((forecast, i) => {
    const actual = Math.round(forecast * (0.91 + ((i * 17 + dayIndex * 11) % 19) / 100));
    return { time: `${String(Math.floor(i / 2)).padStart(2, '0')}:${i % 2 ? '30' : '00'}`, forecast, actual, error: actual - forecast };
  });
}

function formatTimestamp(value: string | null): string {
  if (!value) return 'not available';
  return value.replace('T', ' ').replace(':00Z', ' UTC');
}

function App() {
  const [selected, setSelected] = useState(0);
  const [tab, setTab] = useState<'overview' | 'method'>('overview');
  const [showForecast, setShowForecast] = useState(true);
  const [showActual, setShowActual] = useState(true);
  const [activeIndex, setActiveIndex] = useState(9);
  const [remotePoints, setRemotePoints] = useState<Point[] | null>(null);
  const [remoteVintage, setRemoteVintage] = useState<string | null>(null);
  const [dataMode, setDataMode] = useState<'captured-elexon-snapshot' | 'demo-fallback'>('demo-fallback');
  const day = days[selected];
  const fallbackPoints = useMemo(() => makePoints(day.points, selected), [day, selected]);
  useEffect(() => {
    let cancelled = false;
    setRemotePoints(null);
    fetch(`/api/overview?deliveryDate=${day.date}`)
      .then((response) => response.ok ? response.json() : Promise.reject(new Error('API unavailable')))
      .then((payload) => {
        if (cancelled || !payload.delivery?.points?.length) return;
        setRemotePoints(payload.delivery.points);
        setRemoteVintage(payload.delivery.vintage);
        setDataMode(payload.mode === 'captured-elexon-snapshot' ? 'captured-elexon-snapshot' : 'demo-fallback');
      })
      .catch(() => { if (!cancelled) { setRemoteVintage(null); setDataMode('demo-fallback'); } });
    return () => { cancelled = true; };
  }, [day.date]);
  const points = remotePoints ?? fallbackPoints;
  const metrics = useMemo(() => {
    const abs = points.map((p) => Math.abs(p.error));
    const squared = points.map((p) => p.error * p.error);
    const mae = abs.reduce((a, b) => a + b, 0) / points.length;
    const rmse = Math.sqrt(squared.reduce((a, b) => a + b, 0) / points.length);
    const bias = points.reduce((a, p) => a + p.error, 0) / points.length;
    const mape = points.reduce((a, p) => a + (p.actual ? Math.abs(p.error / p.actual) * 100 : 0), 0) / points.filter((p) => p.actual).length;
    return { mae, rmse, bias, mape };
  }, [points]);
  const max = Math.max(...points.flatMap((p) => [p.forecast, p.actual]));
  const avg = (key: 'forecast' | 'actual') => Math.round(points.reduce((sum, p) => sum + p[key], 0) / points.length);
  const active = points[activeIndex];
  const chartY = (value: number) => 285 - (value / max) * 270;
  const chartX = (index: number) => index * 1000 / (points.length - 1);

  return <div className="app">
    <aside className="sidebar">
      <div className="brand"><span className="mark">≈</span><span>WINDWISE</span><span className="version">PILOT 0.1</span></div>
      <div className="eyebrow">UK POWER / DECISION DESK</div>
      <h1>Forecast clarity before the market window closes.</h1>
      <p className="muted">National wind generation intelligence for day-ahead buyers.</p>
      <div className="side-section">
        <div className="label">DELIVERY DAY</div>
        {days.map((item, i) => <button className={`day-button ${i === selected ? 'active' : ''}`} onClick={() => { setSelected(i); setActiveIndex(9); }} key={item.date}>
          <span>{item.label}</span><small>{item.date}</small>
        </button>)}
      </div>
      <div className="side-section method-mini">
        <div className="label">DECISION RULE</div>
        <p>Use the latest WINDFOR vintage published by <strong>23:00 UTC</strong> on the prior day.</p>
        <span className="source-badge">● ELEXON SOURCES ONLY</span>
      </div>
      <div className="side-footer"><span className="live-dot"></span> Pilot workspace<br /><span className="muted">Data window · 01–31 Jan 2026</span></div>
    </aside>

    <main>
      <header className="page-header">
        <div><div className="eyebrow">DAY-AHEAD DECISION DESK / {day.date}</div><h2>{day.label} <span className="dash">/</span> wind position</h2></div>
        <div className="header-actions">
          <div className="data-state"><span className={`state-dot ${dataMode === 'captured-elexon-snapshot' ? 'captured' : ''}`}></span><span><strong>{dataMode === 'captured-elexon-snapshot' ? 'Captured Elexon data' : 'Demo fallback'}</strong><small>{dataMode === 'captured-elexon-snapshot' ? 'January 2026 snapshot loaded' : 'Source contract verified'}</small></span></div>
          <button className="ghost" onClick={() => setTab(tab === 'overview' ? 'method' : 'overview')}>{tab === 'overview' ? 'Technical method' : 'Back to overview'} ↗</button>
        </div>
      </header>

      {tab === 'overview' ? <>
        <section className="decision-strip"><div className="decision-icon">↗</div><div><span className="label">BUYER TAKEAWAY</span><strong>{metrics.bias < 0 ? 'Wind is tracking below the selected forecast.' : 'Wind is tracking above the selected forecast.'}</strong><p>Keep thermal cover flexible around a <b>{Math.abs(metrics.bias).toFixed(1)} MW</b> average directional miss.</p></div><span className="status"><i></i>{day.status}</span></section>

        <section className="hero-grid">
          <div className="hero-card forecast-card"><div className="card-top"><span className="label">SELECTED FORECAST VINTAGE</span><span className="confidence">CUT-OFF MET</span></div><div className="big-number">{avg('forecast')} <span>MW avg</span></div><p className="card-note">Issued {formatTimestamp(remoteVintage ?? day.vintage)}. The forecast a buyer could actually see before the decision window.</p><div className="progress-line"><span style={{ width: '82%' }}></span></div><small className="micro-note">Vintage selected without hindsight revisions</small></div>
          <div className="hero-card realized-card"><div className="card-top"><span className="label">REALIZED WIND / SAME PERIOD</span><span className="trend">↗ aligned</span></div><div className="big-number">{avg('actual')} <span>MW avg</span></div><p className="card-note">Observed national wind outturn aligned to the same 30-minute periods.</p><div className="mini-stat"><span>Coverage</span><strong>24 / 24 periods</strong></div></div>
          <div className="hero-card accent-card"><div className="card-top"><span className="label">PROCUREMENT SIGNAL</span><span className="signal-badge">ACTION</span></div><div className="signal">{metrics.bias < 0 ? 'Upside' : 'Downside'} <span>wind vs forecast</span></div><p className="card-note">Plan cover around quantified error, not an unqualified point estimate.</p></div>
        </section>

        <section className="chart-card">
          <div className="section-head"><div><div className="label">ALIGNED POSITION / MW</div><h3>Forecast against actual generation</h3><p className="section-caption">Hover the plot to inspect each aligned delivery period.</p></div><div className="chart-controls"><button className={showForecast ? 'toggle active lime-toggle' : 'toggle'} onClick={() => setShowForecast(!showForecast)}><i></i>Forecast</button><button className={showActual ? 'toggle active dark-toggle' : 'toggle'} onClick={() => setShowActual(!showActual)}><i></i>Actual</button></div></div>
          <div className="chart-shell"><div className="y-axis"><span>{max}</span><span>{Math.round(max * .66)}</span><span>{Math.round(max * .33)}</span><span>0</span></div><div className="plot-wrap"><svg viewBox="0 0 1000 300" preserveAspectRatio="none" onMouseLeave={() => setActiveIndex(9)} onMouseMove={(event) => { const rect = event.currentTarget.getBoundingClientRect(); const ratio = Math.max(0, Math.min(1, (event.clientX - rect.left) / rect.width)); setActiveIndex(Math.round(ratio * (points.length - 1))); }}><line x1="0" y1="75" x2="1000" y2="75" /><line x1="0" y1="150" x2="1000" y2="150" /><line x1="0" y1="225" x2="1000" y2="225" />{showForecast && <polyline points={points.map((p, i) => `${chartX(i)},${chartY(p.forecast)}`).join(' ')} className="forecast-line" />}{showActual && <polyline points={points.map((p, i) => `${chartX(i)},${chartY(p.actual)}`).join(' ')} className="actual-line" />}<line className="hover-line" x1={chartX(activeIndex)} x2={chartX(activeIndex)} y1="0" y2="300" />{showForecast && <circle className="hover-dot forecast-dot" cx={chartX(activeIndex)} cy={chartY(active.forecast)} r="5" />}{showActual && <circle className="hover-dot actual-dot" cx={chartX(activeIndex)} cy={chartY(active.actual)} r="5" />}</svg><div className="chart-tooltip" style={{ left: `${(chartX(activeIndex) / 10)}%` }}><strong>{active.time}</strong><span>Forecast <b>{active.forecast} MW</b></span><span>Actual <b>{active.actual} MW</b></span><span className={active.error < 0 ? 'negative' : 'positive'}>Error <b>{active.error > 0 ? '+' : ''}{active.error} MW</b></span></div></div></div><div className="x-axis"><span>00:00</span><span>06:00</span><span>12:00</span><span>18:00</span><span>23:30</span></div>
        </section>

        <section className="lower-grid"><div className="table-card"><div className="section-head"><div><div className="label">SETTLEMENT DRILL-DOWN</div><h3>Where the error landed</h3></div><span className="muted">{points.length} aligned periods</span></div><div className="table-wrap"><table><thead><tr><th>Period</th><th>Forecast</th><th>Actual</th><th>Error</th><th>Signal</th></tr></thead><tbody>{points.filter((_, i) => i % 3 === 0).map((p) => <tr key={p.time}><td><strong>{p.time}</strong></td><td>{p.forecast} MW</td><td>{p.actual} MW</td><td className={p.error < 0 ? 'negative' : 'positive'}>{p.error > 0 ? '+' : ''}{p.error} MW</td><td><span className={`table-pill ${p.error < 0 ? 'under' : 'over'}`}>{p.error < 0 ? 'under' : 'over'}</span></td></tr>)}</tbody></table></div></div><div className="metrics-card"><div className="label">FORECAST PERFORMANCE</div><h3>Error, made legible.</h3><div className="metric"><span>MAE <small>typical miss</small></span><strong>{metrics.mae.toFixed(1)} <em>MW</em></strong></div><div className="metric"><span>RMSE <small>large misses</small></span><strong>{metrics.rmse.toFixed(1)} <em>MW</em></strong></div><div className="metric"><span>BIAS <small>direction</small></span><strong className={metrics.bias < 0 ? 'negative' : ''}>{metrics.bias > 0 ? '+' : ''}{metrics.bias.toFixed(1)} <em>MW</em></strong></div><div className="metric"><span>MAPE <small>relative error</small></span><strong>{metrics.mape.toFixed(1)} <em>%</em></strong></div><p className="metric-foot">Negative bias means actual wind ran below the selected forecast.</p></div></section>
      </> : <Method />}
      <footer><span>Sources: Elexon BMRS FUELHH + WINDFOR</span><span>WindWise pilot / v0.1</span></footer>
    </main>
  </div>;
}

function Method() {
  return <section className="method-page"><div className="eyebrow">INTERNAL REVIEW / TECHNICAL WALKTHROUGH</div><h2>Trace every number back to its decision context.</h2><p className="lede">WindWise deliberately keeps the first version narrow: national wind actuals and forecast vintages from Elexon, aligned at the same 30-minute target time.</p><div className="method-grid"><article><span className="method-num">01</span><h3>Ingest</h3><p><code>FUELHH</code> is filtered to <code>fuelType=WIND</code>. <code>WINDFOR</code> retains both <code>startTime</code> and <code>publishTime</code>. All values are treated as MW averages for 30-minute intervals.</p></article><article><span className="method-num">02</span><h3>Select vintage</h3><p>For delivery day D, eligible records satisfy <code>publishTime ≤ D−1 23:00 UTC</code>. The latest eligible publish time wins; later revisions are excluded from the buyer view.</p></article><article><span className="method-num">03</span><h3>Align & score</h3><p>Forecast and actual rows join on delivery <code>startTime</code>. MAE is mean absolute error, RMSE is the square-root mean squared error, bias is signed actual minus forecast, and MAPE excludes zero actuals.</p></article><article><span className="method-num">04</span><h3>Operate</h3><p>The API serves a stable contract to React. Docker packages both layers. The visible fallback is deterministic demo data and is explicitly labelled so it cannot be mistaken for a live refresh.</p></article></div><div className="endpoint"><span className="label">SOURCE ENDPOINTS</span><p>bmrs.elexon.co.uk/api-documentation/endpoint/datasets/FUELHH/stream</p><p>bmrs.elexon.co.uk/api-documentation/endpoint/datasets/WINDFOR/stream</p></div></section>;
}

createRoot(document.getElementById('root')!).render(<App />);
